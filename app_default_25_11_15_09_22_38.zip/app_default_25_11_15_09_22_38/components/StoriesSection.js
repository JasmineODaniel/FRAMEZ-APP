import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const stories = [
  { id: '1', name: 'Anna', icon: 'account-circle' },
  { id: '2', name: 'Ben', icon: 'account-circle-outline' },
  { id: '3', name: 'Cara', icon: 'account-circle' },
  { id: '4', name: 'David', icon: 'account-circle-outline' },
  { id: '5', name: 'Ellie', icon: 'account-circle' },
  { id: '6', name: 'Frank', icon: 'account-circle-outline' },
];

export default function StoriesSection() {
  return (
    <View style={styles.container}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {stories.map((story) => (
          <TouchableOpacity
            key={story.id}
            style={styles.storyItem}
            activeOpacity={0.7}
            accessibilityRole="button"
            accessibilityLabel={`View story by ${story.name}`}
          >
            <View style={styles.iconWrapper}>
              <Icon name={story.icon} size={42} color="#bb86fc" />
            </View>
            <Text style={styles.storyName} numberOfLines={1}>
              {story.name}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.12)',
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  storyItem: {
    alignItems: 'center',
    marginHorizontal: 10,
    width: 72,
  },
  iconWrapper: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 36,
    padding: 6,
    marginBottom: 6,
  },
  storyName: {
    color: '#ccc',
    fontSize: 12,
    fontWeight: '600',
  },
});
