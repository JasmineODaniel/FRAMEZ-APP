import React, { useEffect, useState, useCallback } from 'react';
import {
  Modal,
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  serverTimestamp,
  doc,
  getDoc,
} from 'firebase/firestore';
import { firestore } from '../firebaseConfig';
import { useAuth } from '../context/AuthContext';
import { formatDistanceToNow } from 'date-fns';

export default function CommentModal({ visible, postId, onClose }) {
  const { currentUser } = useAuth();
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newComment, setNewComment] = useState('');

  useEffect(() => {
    if (!postId || !visible) return;

    const q = query(
      collection(firestore, 'posts', postId, 'comments'),
      orderBy('timestamp', 'asc')
    );
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const loadedComments = [];
      querySnapshot.forEach((doc) =>
        loadedComments.push({ id: doc.id, ...doc.data() })
      );
      setComments(loadedComments);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [postId, visible]);

  const handleAddComment = useCallback(async () => {
    if (!newComment.trim()) {
      Alert.alert('Validation', 'Comment cannot be empty.');
      return;
    }
    try {
      await addDoc(collection(firestore, 'posts', postId, 'comments'), {
        authorId: currentUser.uid,
        authorName: currentUser.displayName || currentUser.email,
        text: newComment.trim(),
        timestamp: serverTimestamp(),
      });
      setNewComment('');
    } catch (error) {
      Alert.alert('Error', 'Failed to post comment.');
    }
  }, [newComment, postId, currentUser]);

  const renderItem = ({ item }) => (
    <View style={styles.commentItem}>
      <Text style={styles.commentAuthor}>{item.authorName || 'Unknown'}</Text>
      <Text style={styles.commentText}>{item.text}</Text>
      <Text style={styles.commentTimestamp}>
        {item.timestamp?.toDate
          ? formatDistanceToNow(item.timestamp.toDate(), { addSuffix: true })
          : ''}
      </Text>
    </View>
  );

  return (
    <Modal
      visible={visible}
      animationType="slide"
      onRequestClose={onClose}
      transparent={false}
    >
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.select({ ios: 'padding', android: undefined })}
      >
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Comments</Text>
          <TouchableOpacity
            onPress={onClose}
            accessibilityRole="button"
            accessibilityLabel="Close comments"
          >
            <Icon name="close" size={28} color="#fff" />
          </TouchableOpacity>
        </View>
        {!loading && comments.length === 0 && (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No comments yet. Be first!</Text>
          </View>
        )}
        <FlatList
          data={comments}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          contentContainerStyle={styles.listContent}
          keyboardShouldPersistTaps="handled"
        />
        <View style={styles.inputWrapper}>
          <TextInput
            style={styles.input}
            placeholder="Add a comment..."
            placeholderTextColor="#999"
            value={newComment}
            onChangeText={setNewComment}
            multiline={false}
            accessibilityLabel="Add new comment"
          />
          <TouchableOpacity
            onPress={handleAddComment}
            accessibilityRole="button"
            accessibilityLabel="Send comment"
            style={styles.sendButton}
          >
            <Icon name="send" size={24} color="#bb86fc" />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
    paddingTop: 54,
    paddingHorizontal: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#bb86fc',
  },
  listContent: {
    paddingBottom: 80,
  },
  commentItem: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 20,
    padding: 12,
    marginBottom: 10,
  },
  commentAuthor: {
    fontWeight: '700',
    color: '#bb86fc',
    marginBottom: 4,
    fontSize: 14,
  },
  commentText: {
    color: '#eee',
    fontSize: 15,
    marginBottom: 6,
  },
  commentTimestamp: {
    fontSize: 11,
    fontStyle: 'italic',
    color: '#999',
    textAlign: 'right',
  },
  inputWrapper: {
    position: 'absolute',
    bottom: 12,
    left: 16,
    right: 16,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 24,
    paddingHorizontal: 16,
    paddingVertical: 6,
  },
  input: {
    flex: 1,
    color: '#fff',
    fontSize: 16,
    paddingVertical: 6,
  },
  sendButton: {
    marginLeft: 12,
  },
  emptyContainer: {
    marginTop: 24,
    alignItems: 'center',
  },
  emptyText: {
    color: '#999',
    fontSize: 16,
    fontStyle: 'italic',
  },
});
