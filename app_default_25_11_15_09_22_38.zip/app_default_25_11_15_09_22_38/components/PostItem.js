import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Alert,
  TextInput,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { formatDistanceToNow } from 'date-fns';

export default function PostItem({
  post,
  onLike,
  onComment,
  onEdit,
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedText, setEditedText] = useState(post.text);

  const onSaveEdit = useCallback(() => {
    if (!editedText.trim()) {
      Alert.alert('Validation', 'Post text cannot be empty.');
      return;
    }
    onEdit(post.id, editedText.trim());
    setIsEditing(false);
  }, [editedText, onEdit, post.id]);

  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <Text style={styles.authorName}>
          {post.authorName || 'Unknown'}
        </Text>
        <Text style={styles.timestamp}>
          {post.timestamp
            ? formatDistanceToNow(post.timestamp.toDate(), {
                addSuffix: true,
              })
            : ''}
        </Text>
      </View>
      <View style={styles.content}>
        {isEditing ? (
          <TextInput
            style={styles.editInput}
            multiline
            value={editedText}
            onChangeText={setEditedText}
            autoFocus
            accessibilityLabel="Edit post text"
          />
        ) : (
          <Text style={styles.text}>{post.text}</Text>
        )}
        {post.imageURL ? (
          <Image
            source={{ uri: post.imageURL }}
            style={styles.image}
            resizeMode="cover"
            accessible
            accessibilityLabel="Post image"
          />
        ) : null}
      </View>
      <View style={styles.actions}>
        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => onLike(post.id)}
          accessibilityRole="button"
          accessibilityLabel={`Like post by ${post.authorName}`}
        >
          <Icon
            name={post.likedByCurrentUser ? 'heart' : 'heart-outline'}
            size={22}
            color="#fff"
          />
          <Text style={styles.actionText}>{post.likesCount || 0}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => onComment(post.id)}
          accessibilityRole="button"
          accessibilityLabel={`Comment on post by ${post.authorName}`}
        >
          <Icon name="comment-outline" size={22} color="#fff" />
          <Text style={styles.actionText}>{post.commentsCount || 0}</Text>
        </TouchableOpacity>
        {post.isAuthor && !isEditing && (
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => setIsEditing(true)}
            accessibilityRole="button"
            accessibilityLabel="Edit post"
          >
            <Icon name="pencil-outline" size={22} color="#fff" />
          </TouchableOpacity>
        )}
        {post.isAuthor && isEditing && (
          <TouchableOpacity
            style={[styles.actionButton, styles.saveButton]}
            onPress={onSaveEdit}
            accessibilityRole="button"
            accessibilityLabel="Save edited post"
          >
            <Icon name="content-save-outline" size={22} color="#bb86fc" />
          </TouchableOpacity>
        )}
        {post.isAuthor && isEditing && (
          <TouchableOpacity
            style={[styles.actionButton, styles.cancelButton]}
            onPress={() => {
              setIsEditing(false);
              setEditedText(post.text);
            }}
            accessibilityRole="button"
            accessibilityLabel="Cancel editing post"
          >
            <Icon name="close-circle-outline" size={22} color="#ff5555" />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 20,
    marginVertical: 8,
    marginHorizontal: 12,
    padding: 16,
    shadowColor: '#00000088',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 8,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  authorName: {
    fontWeight: '700',
    fontSize: 16,
    color: '#bb86fc',
  },
  timestamp: {
    fontSize: 12,
    color: '#ccc',
    fontStyle: 'italic',
  },
  content: {
    marginBottom: 12,
  },
  text: {
    color: '#eee',
    fontSize: 15,
    marginBottom: 8,
  },
  image: {
    width: '100%',
    height: 180,
    borderRadius: 16,
    backgroundColor: '#222',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 24,
  },
  actionText: {
    color: '#fff',
    marginLeft: 6,
    fontWeight: '600',
    fontSize: 14,
  },
  editInput: {
    color: '#eee',
    fontSize: 15,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 10,
    minHeight: 60,
  },
  saveButton: {
    marginRight: 8,
  },
  cancelButton: {},
});
