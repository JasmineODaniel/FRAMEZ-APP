import { useEffect, useState, useCallback } from 'react';
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  updateDoc,
  doc,
  serverTimestamp,
  arrayUnion,
  arrayRemove,
  getDoc,
} from 'firebase/firestore';
import { firestore } from '../firebaseConfig';
import { useAuth } from '../context/AuthContext';

export default function usePosts() {
  const { currentUser } = useAuth();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(firestore, 'posts'), orderBy('timestamp', 'desc'));
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const loadedPosts = [];
      querySnapshot.forEach((docSnap) => {
        const data = docSnap.data();
        loadedPosts.push({
          id: docSnap.id,
          authorId: data.authorId,
          authorName: data.authorName || 'Unknown',
          timestamp: data.timestamp,
          text: data.text,
          imageURL: data.imageURL || null,
          likesCount: Array.isArray(data.likedBy) ? data.likedBy.length : 0,
          likedByCurrentUser:
            currentUser && Array.isArray(data.likedBy)
              ? data.likedBy.includes(currentUser.uid)
              : false,
          commentsCount: data.commentsCount || 0,
          isAuthor: currentUser ? data.authorId === currentUser.uid : false,
        });
      });
      setPosts(loadedPosts);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [currentUser]);

  const createPost = useCallback(
    async (text, imageURL) => {
      if (!currentUser) throw new Error('User not authenticated');
      if (!text.trim() && !imageURL) throw new Error('Post must have text or image.');

      const postData = {
        authorId: currentUser.uid,
        authorName: currentUser.displayName || currentUser.email,
        timestamp: serverTimestamp(),
        text: text.trim(),
        imageURL: imageURL || null,
        likedBy: [],
        commentsCount: 0,
      };

      await addDoc(collection(firestore, 'posts'), postData);
    },
    [currentUser]
  );

  const editPost = useCallback(
    async (postId, newText) => {
      if (!currentUser) throw new Error('User not authenticated');
      if (!newText.trim()) throw new Error('Post text cannot be empty.');

      const postRef = doc(firestore, 'posts', postId);
      const postSnap = await getDoc(postRef);
      if (!postSnap.exists()) throw new Error('Post not found');
      if (postSnap.data().authorId !== currentUser.uid)
        throw new Error('Not authorized to edit this post');

      await updateDoc(postRef, {
        text: newText.trim(),
      });
    },
    [currentUser]
  );

  const likePost = useCallback(
    async (postId) => {
      if (!currentUser) throw new Error('User not authenticated');

      const postRef = doc(firestore, 'posts', postId);
      const postSnap = await getDoc(postRef);
      if (!postSnap.exists()) throw new Error('Post not found');

      const likedBy = postSnap.data().likedBy || [];

      if (likedBy.includes(currentUser.uid)) {
        // Unlike
        await updateDoc(postRef, {
          likedBy: arrayRemove(currentUser.uid),
        });
      } else {
        // Like
        await updateDoc(postRef, {
          likedBy: arrayUnion(currentUser.uid),
        });
      }
    },
    [currentUser]
  );

  return { posts, loading, createPost, editPost, likePost };
}
