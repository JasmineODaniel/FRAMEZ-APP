import { useEffect, useState, useCallback } from 'react';
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  serverTimestamp,
} from 'firebase/firestore';
import { firestore } from '../firebaseConfig';
import { useAuth } from '../context/AuthContext';

export default function useComments(postId) {
  const { currentUser } = useAuth();
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!postId) {
      setComments([]);
      setLoading(false);
      return;
    }
    const q = query(
      collection(firestore, 'posts', postId, 'comments'),
      orderBy('timestamp', 'asc')
    );
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const loadedComments = [];
      querySnapshot.forEach((doc) => {
        loadedComments.push({ id: doc.id, ...doc.data() });
      });
      setComments(loadedComments);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [postId]);

  const addComment = useCallback(
    async (text) => {
      if (!currentUser) throw new Error('User not authenticated');
      if (!text.trim()) throw new Error('Comment text cannot be empty');

      await addDoc(collection(firestore, 'posts', postId, 'comments'), {
        authorId: currentUser.uid,
        authorName: currentUser.displayName || currentUser.email,
        text: text.trim(),
        timestamp: serverTimestamp(),
      });
    },
    [postId, currentUser]
  );

  return { comments, loading, addComment };
}
