import React, { useEffect, useState } from 'react';
import { StatusBar, LogBox } from 'react-native';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { AuthProvider } from './context/AuthContext';
import MainNavigator from './navigation/MainNavigator';
import SplashScreen from './screens/SplashScreen';

LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
]);

const MyDarkTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: '#121212',
    card: 'rgba(255,255,255,0.08)', // glassmorphism effect for headers, cards
    text: '#ffffff',
    primary: '#bb86fc',
    border: 'rgba(255,255,255,0.12)',
    notification: '#ff80ab',
  },
};

export default function App() {
  const [appIsReady, setAppIsReady] = useState(false);

  useEffect(() => {
    // Simulate loading resources, auth state handled in context
    const prepare = async () => {
      try {
        await new Promise((resolve) => setTimeout(resolve, 1200));
      } catch (e) {
        // Ignore errors
      } finally {
        setAppIsReady(true);
      }
    };
    prepare();
  }, []);

  if (!appIsReady) {
    return <SplashScreen />;
  }

  return (
    <AuthProvider>
      <NavigationContainer theme={MyDarkTheme}>
        <StatusBar
          barStyle="light-content"
          backgroundColor="#121212"
          translucent={false}
        />
        <MainNavigator />
      </NavigationContainer>
    </AuthProvider>
  );
}
