# Framez - React Native Social App

## Project Overview
Framez is a mobile social application built with React Native and Expo. It allows users to register, log in, and share posts containing text and/or images. Users can view a real-time feed of posts from all users, interact by liking posts, and edit their own posts. Each user has a profile screen displaying their information and posts. The app features dark mode with a sleek glassmorphism UI style and modern icons.

## Features
- Secure user authentication with Firebase (email/password)
- Persistent login sessions
- Create and upload posts containing text and optional image URL
- Real-time feed showing posts from all users, newest first
- Like and edit posts (editing allowed only for own posts)
- User profile screen with personal info and user posts
- Stories section at top of feed with modern icons (no images)
- Dark mode (#121212 background) with glassmorphism styling
- Modern iconography for all UI elements
- Responsive and smooth navigation with React Navigation

## Prerequisites
- Node.js (version 18 recommended)
- Expo CLI (`npm install -g expo-cli`)
- Firebase account with a project created

## Firebase Setup Instructions
1. Go to https://console.firebase.google.com/ and create a new project.
2. Enable **Authentication** > Sign-in method > Email/Password.
3. Create a **Cloud Firestore** database in test mode (or locked mode if you set rules accordingly).
4. In Project settings, under the **General** tab, add a new Web app to get your Firebase SDK config.
5. Copy the Firebase configuration values.

## Configuration
1. Create a `.env` file in the root of the project (copy from `.env.example`).
2. Paste your Firebase credentials from the Firebase console into `.env`:

    FIREBASE_API_KEY=your_api_key_here  
    FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com  
    FIREBASE_PROJECT_ID=your_project_id  
    FIREBASE_STORAGE_BUCKET=your_project.appspot.com  
    FIREBASE_MESSAGING_SENDER_ID=your_messaging_sender_id  
    FIREBASE_APP_ID=your_firebase_app_id

## Installation
Clone the repository and install dependencies:

    git clone https://github.com/yourusername/framez.git
    cd framez
    npm install

## Running the App on Expo Go
Start the development server:

    npm start

Use the Expo Go app on your Android/iOS device or an emulator to scan the QR code and run the app.

## Preview on Appetize.io
You can upload the built app to https://appetize.io/ for online preview and sharing.

## VS Code Setup Instructions by jasmine daniel

To develop Framez efficiently in VS Code, follow these steps:

1. **Extensions to install:**
   - ESLint (dbaeumer.vscode-eslint)
   - Prettier - Code formatter (esbenp.prettier-vscode)
   - React Native Tools (msjsdiag.vscode-react-native)
   - Firebase Explorer (ferdaber.firebase-explorer)

2. **Settings:**
   Configure VS Code to use ESLint and Prettier for code formatting and linting.

3. **Debugging:**
   - Use the React Native Tools extension to run/debug on simulators or devices.
   - Create a launch configuration in `.vscode/launch.json` for React Native Expo.

4. **Environment Variables:**
   - Install `dotenv` extension for environment variable highlighting.
   - Make sure to never commit your `.env` file; use `.env.example` for reference.

## App Structure Overview
- `App.js` - Main entry point wrapping navigation and auth provider.
- `context/AuthContext.js` - Manages Firebase authentication and user state.
- `navigation/MainNavigator.js` - React Navigation stacks and tabs.
- `screens/` - App screens including Login, Signup, Feed, Profile, CreatePost, Splash.
- `components/` - Reusable UI components like PostItem, CommentModal, StoriesSection.
- `hooks/` - Custom hooks for posts and comments data handling.
- `firebaseConfig.js` - Firebase app initialization and exports.
- `.env` - Environment variables for Firebase credentials.

## Authentication Flow
- Users register with email and password, optionally setting a display name.
- Users log in and remain logged in across app restarts.
- Logout option is available on Profile screen (add as needed).

## Posts Creation and Feed
- Posts can contain text and/or an image URL.
- Feed displays all posts from all users in descending order by timestamp.
- Users can like posts and edit their own posts inline.
- Comments can be viewed and added in a modal overlay on posts in the feed.

## Profile Screen
- Displays current user's display name and email.
- Lists all posts created by the current user.
- Likes and editing capabilities available here as well.

## UI Style Notes
- Dark mode with #121212 background throughout.
- Glassmorphism style with translucent container backgrounds.
- Modern vector icons used throughout.
- No profile photo editing currently.
- Stories section at top of feed uses icons only, no images.
- Create Post button fixed at bottom right on feed screen.

## Testing Instructions
- Run `npm run lint` to check for linting errors.
- Use Expo Go on device/emulator to manually test authentication, posting, liking, editing, and profile features.
- Unit and snapshot tests are included in `/tests` folder (run with jest if configured).

## Deployment Notes
- The app is designed for Expo Go development.
- To publish, use `expo build` commands or EAS for app store submission.
- Ensure environment variables are handled securely for production.

---

For any questions or assistance setting up, please contact jasmine daniel.

Thank you for choosing Framez!
