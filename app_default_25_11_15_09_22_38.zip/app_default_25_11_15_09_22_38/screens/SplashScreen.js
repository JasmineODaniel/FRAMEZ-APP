import React, { useEffect } from 'react';
import { View, Image, StyleSheet, StatusBar } from 'react-native';
import * as SplashScreenExpo from 'expo-splash-screen';

SplashScreenExpo.preventAutoHideAsync();

export default function SplashScreen() {
  useEffect(() => {
    const hideSplash = async () => {
      await new Promise((resolve) => setTimeout(resolve, 1500));
      await SplashScreenExpo.hideAsync();
    };
    hideSplash();
  }, []);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#121212" />
      <Image
        source={{
          uri: 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?auto=format&fit=crop&w=256&q=80',
        }}
        style={styles.logo}
        resizeMode="contain"
        accessible
        accessibilityLabel="Framez logo"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 180,
    height: 180,
    borderRadius: 20,
    opacity: 0.9,
  },
});
