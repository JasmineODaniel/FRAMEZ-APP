import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useAuth } from '../context/AuthContext';

export default function SignupScreen({ navigation }) {
  const { signup } = useAuth();
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSignup = async () => {
    if (!email.trim() || !password || !confirmPassword) {
      Alert.alert('Validation Error', 'Please fill all required fields.');
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert('Validation Error', 'Passwords do not match.');
      return;
    }
    setLoading(true);
    try {
      await signup(email.trim(), password, displayName.trim() || null);
    } catch (error) {
      Alert.alert('Signup Failed', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.select({ ios: 'padding', android: undefined })}
      keyboardVerticalOffset={Platform.select({ ios: 60, android: 0 })}
    >
      <View style={styles.glassContainer}>
        <Text style={styles.title}>Create Account</Text>

        <View style={styles.inputWrapper}>
          <Icon name="account-outline" size={22} color="#ffffffcc" />
          <TextInput
            placeholder="Display Name (optional)"
            placeholderTextColor="#cccccc"
            style={styles.input}
            autoCapitalize="words"
            value={displayName}
            onChangeText={setDisplayName}
            accessibilityLabel="Display Name input"
          />
        </View>

        <View style={styles.inputWrapper}>
          <Icon name="email-outline" size={22} color="#ffffffcc" />
          <TextInput
            placeholder="Email"
            placeholderTextColor="#cccccc"
            style={styles.input}
            autoCapitalize="none"
            keyboardType="email-address"
            textContentType="emailAddress"
            value={email}
            onChangeText={setEmail}
            autoComplete="email"
            accessibilityLabel="Email input"
          />
        </View>
        <View style={styles.inputWrapper}>
          <Icon name="lock-outline" size={22} color="#ffffffcc" />
          <TextInput
            placeholder="Password"
            placeholderTextColor="#cccccc"
            style={styles.input}
            secureTextEntry
            value={password}
            onChangeText={setPassword}
            autoComplete="password"
            accessibilityLabel="Password input"
          />
        </View>
        <View style={styles.inputWrapper}>
          <Icon name="lock-check-outline" size={22} color="#ffffffcc" />
          <TextInput
            placeholder="Confirm Password"
            placeholderTextColor="#cccccc"
            style={styles.input}
            secureTextEntry
            value={confirmPassword}
            onChangeText={setConfirmPassword}
            autoComplete="password"
            accessibilityLabel="Confirm Password input"
          />
        </View>

        <TouchableOpacity
          style={styles.signupButton}
          onPress={handleSignup}
          disabled={loading}
          accessibilityRole="button"
          accessibilityLabel="Sign Up button"
        >
          <Text style={styles.signupButtonText}>
            {loading ? 'Signing up...' : 'Sign Up'}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navigation.navigate('Login')}
          accessibilityRole="button"
          accessibilityLabel="Go to Login"
        >
          <Text style={styles.loginText}>
            Already have an account?{' '}
            <Text style={styles.loginLink}>Login</Text>
          </Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  glassContainer: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 18,
    padding: 32,
    shadowColor: '#ffffff44',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 16,
    elevation: 12,
  },
  title: {
    fontSize: 28,
    fontWeight: '900',
    color: '#bb86fc',
    textAlign: 'center',
    marginBottom: 28,
    letterSpacing: 1,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    paddingHorizontal: 12,
    marginBottom: 18,
  },
  input: {
    flex: 1,
    height: 48,
    color: '#fff',
    paddingLeft: 12,
    fontSize: 16,
  },
  signupButton: {
    backgroundColor: '#bb86fc',
    borderRadius: 16,
    paddingVertical: 14,
    marginBottom: 20,
    alignItems: 'center',
    shadowColor: '#bb86fc',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
  },
  signupButtonText: {
    fontWeight: '700',
    fontSize: 18,
    color: '#121212',
  },
  loginText: {
    color: '#ccc',
    textAlign: 'center',
    fontSize: 14,
  },
  loginLink: {
    color: '#bb86fc',
    fontWeight: '700',
  },
});
