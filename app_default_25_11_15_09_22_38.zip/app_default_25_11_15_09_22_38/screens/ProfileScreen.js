import React from 'react';
import { View, Text, StyleSheet, FlatList, Alert } from 'react-native';
import { useAuth } from '../context/AuthContext';
import usePosts from '../hooks/usePosts';
import PostItem from '../components/PostItem';

export default function ProfileScreen() {
  const { currentUser } = useAuth();
  const { posts, loading, likePost, editPost } = usePosts();

  const userPosts = posts.filter((p) => p.authorId === currentUser?.uid);

  const onLike = async (postId) => {
    try {
      await likePost(postId);
    } catch (e) {
      Alert.alert('Error', 'Failed to like post.');
    }
  };

  const onEdit = async (postId, newText) => {
    try {
      await editPost(postId, newText);
    } catch (e) {
      Alert.alert('Error', 'Failed to edit post.');
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.userInfoContainer}>
        <Text style={styles.displayName}>
          {currentUser?.displayName || 'User'}
        </Text>
        <Text style={styles.email}>{currentUser?.email}</Text>
      </View>
      <Text style={styles.sectionTitle}>Your Posts</Text>
      {loading && <Text style={styles.loadingText}>Loading posts...</Text>}
      {!loading && userPosts.length === 0 && (
        <Text style={styles.emptyText}>You have no posts yet.</Text>
      )}
      <FlatList
        data={userPosts}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <PostItem
            post={item}
            onLike={onLike}
            onComment={() => Alert.alert('Comments Disabled', 'Commenting is disabled on profile screen.')}
            onEdit={onEdit}
          />
        )}
        contentContainerStyle={{ paddingBottom: 60 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
    paddingHorizontal: 12,
    paddingTop: 16,
  },
  userInfoContainer: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 24,
    alignItems: 'center',
  },
  displayName: {
    fontSize: 24,
    fontWeight: '700',
    color: '#bb86fc',
    marginBottom: 6,
  },
  email: {
    fontSize: 16,
    color: '#ccc',
  },
  sectionTitle: {
    color: '#bb86fc',
    fontWeight: '700',
    fontSize: 20,
    marginBottom: 12,
    marginLeft: 8,
  },
  loadingText: {
    color: '#ccc',
    fontStyle: 'italic',
    textAlign: 'center',
    marginTop: 12,
  },
  emptyText: {
    color: '#666',
    fontStyle: 'italic',
    textAlign: 'center',
    marginTop: 20,
  },
});
