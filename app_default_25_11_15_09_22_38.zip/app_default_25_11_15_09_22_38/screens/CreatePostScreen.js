import React, { useState } from 'react';
import {
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Text,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import usePosts from '../hooks/usePosts';

export default function CreatePostScreen({ navigation }) {
  const [text, setText] = useState('');
  const [imageURL, setImageURL] = useState('');
  const [loading, setLoading] = useState(false);
  const { createPost } = usePosts();

  const handleSubmit = async () => {
    if (!text.trim() && !imageURL.trim()) {
      Alert.alert('Validation', 'Please enter text or image URL.');
      return;
    }
    setLoading(true);
    try {
      await createPost(text.trim(), imageURL.trim() || null);
      setText('');
      setImageURL('');
      navigation.goBack();
    } catch (error) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.select({ ios: 'padding', android: undefined })}
      keyboardVerticalOffset={Platform.select({ ios: 80, android: 0 })}
    >
      <ScrollView
        contentContainerStyle={styles.scrollContainer}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.glassContainer}>
          <Text style={styles.title}>Create New Post</Text>
          <View style={styles.inputWrapper}>
            <Icon name="pencil-outline" size={22} color="#ffffffcc" />
            <TextInput
              placeholder="What's on your mind?"
              placeholderTextColor="#ccc"
              style={styles.inputText}
              multiline
              value={text}
              onChangeText={setText}
              accessibilityLabel="Post text input"
              textAlignVertical="top"
              maxLength={1000}
            />
          </View>
          <View style={styles.inputWrapper}>
            <Icon name="image-outline" size={22} color="#ffffffcc" />
            <TextInput
              placeholder="Image URL (optional)"
              placeholderTextColor="#ccc"
              style={styles.input}
              value={imageURL}
              onChangeText={setImageURL}
              keyboardType="url"
              accessibilityLabel="Image URL input"
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>
          <TouchableOpacity
            style={[styles.submitButton, loading && styles.disabledButton]}
            onPress={handleSubmit}
            disabled={loading}
            accessibilityRole="button"
            accessibilityLabel="Submit new post"
          >
            <Text style={styles.submitButtonText}>
              {loading ? 'Posting...' : 'Post'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 40,
  },
  glassContainer: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 18,
    padding: 28,
    shadowColor: '#ffffff44',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 16,
    elevation: 12,
  },
  title: {
    fontSize: 28,
    fontWeight: '900',
    color: '#bb86fc',
    textAlign: 'center',
    marginBottom: 24,
    letterSpacing: 1,
  },
  inputWrapper: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    paddingHorizontal: 12,
    marginBottom: 20,
    alignItems: 'flex-start',
  },
  inputText: {
    flex: 1,
    minHeight: 100,
    color: '#fff',
    fontSize: 16,
    paddingLeft: 12,
    paddingTop: 12,
  },
  input: {
    flex: 1,
    height: 48,
    color: '#fff',
    fontSize: 16,
    paddingLeft: 12,
  },
  submitButton: {
    backgroundColor: '#bb86fc',
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: 'center',
    shadowColor: '#bb86fc',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
  },
  disabledButton: {
    opacity: 0.6,
  },
  submitButtonText: {
    fontWeight: '700',
    fontSize: 18,
    color: '#121212',
  },
});
