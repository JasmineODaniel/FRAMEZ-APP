import React, { useState, useCallback } from 'react';
import {
  View,
  StyleSheet,
  FlatList,
  RefreshControl,
  TouchableOpacity,
  Modal,
} from 'react-native';
import StoriesSection from '../components/StoriesSection';
import PostItem from '../components/PostItem';
import CommentModal from '../components/CommentModal';
import usePosts from '../hooks/usePosts';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

export default function FeedScreen() {
  const { posts, loading, likePost, editPost } = usePosts();
  const [selectedPostId, setSelectedPostId] = useState(null);
  const [commentsVisible, setCommentsVisible] = useState(false);
  const navigation = useNavigation();

  const onLike = useCallback(
    async (postId) => {
      try {
        await likePost(postId);
      } catch {}
    },
    [likePost]
  );

  const onComment = useCallback((postId) => {
    setSelectedPostId(postId);
    setCommentsVisible(true);
  }, []);

  const onEdit = useCallback(
    async (postId, newText) => {
      try {
        await editPost(postId, newText);
      } catch {}
    },
    [editPost]
  );

  const closeComments = () => {
    setCommentsVisible(false);
    setSelectedPostId(null);
  };

  return (
    <View style={styles.container}>
      <StoriesSection />
      <FlatList
        data={posts}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <PostItem
            post={item}
            onLike={onLike}
            onComment={onComment}
            onEdit={onEdit}
          />
        )}
        refreshControl={
          <RefreshControl refreshing={loading} tintColor="#bb86fc" />
        }
        contentContainerStyle={{ paddingBottom: 90 }}
      />
      <Modal visible={commentsVisible} animationType="slide" onRequestClose={closeComments}>
        <CommentModal visible={commentsVisible} postId={selectedPostId} onClose={closeComments} />
      </Modal>
      <TouchableOpacity
        style={styles.createPostButton}
        onPress={() => navigation.navigate('CreatePost')}
        accessibilityRole="button"
        accessibilityLabel="Create new post"
      >
        <Icon name="plus" size={28} color="#121212" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  createPostButton: {
    position: 'absolute',
    right: 20,
    bottom: 20,
    backgroundColor: '#bb86fc',
    borderRadius: 28,
    width: 56,
    height: 56,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 10,
    shadowColor: '#bb86fc',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.55,
    shadowRadius: 12,
  },
});
