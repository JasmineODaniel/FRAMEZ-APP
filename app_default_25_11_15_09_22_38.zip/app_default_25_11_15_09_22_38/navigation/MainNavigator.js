import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useAuth } from '../context/AuthContext';
import LoginScreen from '../screens/LoginScreen';
import SignupScreen from '../screens/SignupScreen';
import FeedScreen from '../screens/FeedScreen';
import ProfileScreen from '../screens/ProfileScreen';
import CreatePostScreen from '../screens/CreatePostScreen';
import { View, Text } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const AuthStack = createNativeStackNavigator();
const AppStack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const tabBarOptions = {
  activeTintColor: '#ffffff',
  inactiveTintColor: '#888888',
  style: {
    backgroundColor: '#121212',
    borderTopWidth: 0,
  },
  keyboardHidesTabBar: true,
};

const screenOptions = {
  headerStyle: {
    backgroundColor: 'rgba(255,255,255,0.08)', // glassmorphism effect
    borderBottomWidth: 0,
    shadowColor: 'transparent',
  },
  headerTintColor: 'white',
  headerTitleStyle: {
    fontWeight: 'bold',
  },
  contentStyle: {
    backgroundColor: '#121212',
  },
};

function BottomTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: '#fff',
        tabBarInactiveTintColor: '#888',
        tabBarStyle: {
          backgroundColor: '#121212',
          borderTopWidth: 0,
          elevation: 0,
          shadowOpacity: 0,
        },
        tabBarIcon: ({ color, size }) => {
          let iconName;
          switch (route.name) {
            case 'Feed':
              iconName = 'home-outline';
              break;
            case 'Profile':
              iconName = 'account-circle-outline';
              break;
            case 'CreatePost':
              iconName = 'plus-box-outline';
              break;
            default:
              iconName = 'circle';
          }
          return <Icon name={iconName} size={size} color={color} />;
        },
        tabBarActiveBackgroundColor: 'rgba(255,255,255,0.12)',
      })}
    >
      <Tab.Screen name="Feed" component={FeedScreen} />
      <Tab.Screen
        name="CreatePost"
        component={CreatePostScreen}
        options={{ title: 'New Post' }}
      />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

export default function MainNavigator() {
  const { currentUser, initializing } = useAuth();

  if (initializing) {
    return null; // SplashScreen handles initial loading
  }

  return (
    <AppStack.Navigator screenOptions={screenOptions} initialRouteName="Root">
      {currentUser ? (
        <AppStack.Screen
          name="Root"
          component={BottomTabs}
          options={{ headerShown: false }}
        />
      ) : (
        <>
          <AppStack.Screen
            name="Login"
            component={LoginScreen}
            options={{ title: 'Login' }}
          />
          <AppStack.Screen
            name="Signup"
            component={SignupScreen}
            options={{ title: 'Sign Up' }}
          />
        </>
      )}
    </AppStack.Navigator>
  );
}
